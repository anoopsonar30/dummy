from Numberjack import *
from math import *

# Class subtypes that exist only to distinguish their behavior in the objective
class AndVariable(Variable):
    None
    
class XOrVariable(Variable):
    None

# Objective functin for model based diagnosis
def add_diagnosis_objective(model,AND_fail,XOR_fail):
    # Build a dictionary of success probabilities
    success_probs = dict()
        
    # Say that 'and' gates have a success probability of 0.98
    success_probs['AndVariable'] = 0.98
        
    # 'xor' gates have a success probability of 0.97
    success_probs['XOrVariable'] = 0.97
    
    # Define an empty objective function to maximize
    obj = 0
    
    # Loop through model variables
    for v in model.variables:
        #if type(v).__name__ in success_probs.keys():
        #    obj += v*log(success_probs[type(v).__name__]) + (1 - v)*log(1-success_probs[type(v).__name__])
        if type(v).__name__ == 'AndVariable':
            obj += v*log(1 - AND_fail) + (1 - v)*log(AND_fail)
        elif type(v).__name__ == 'XOrVariable':
            obj += v*log(1 - XOR_fail) + (1 - v)*log(XOR_fail)
    
    model.add(Maximize(obj))
    return (model,obj)