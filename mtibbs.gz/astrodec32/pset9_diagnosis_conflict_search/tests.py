from nose.tools import assert_equal, ok_, assert_almost_equal
from Numberjack import *
from math import *
from utils import *

def test_ok():
    try:
        from IPython.display import display_html
        display_html("""<div class="alert alert-success">
        <strong>Test passed!!</strong>
        </div>""", raw=True)
    except:
        print("test ok!!")
        

# It looks like I have to redeclare the variables each time or solutions stick around
# Mistral was giving non-deterministic behavior, so using SCIP
def test_add_AndVariable(f):
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    A1 = AndVariable('A1') 
    model = Model()
    model += A == 1
    model += B == 1
    model += A1 == 1
    model = f(model,A1,A,B,C)
    
    # Tests are only using satisfiability.
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in1 = in2 = 1.") 
    ok_(C.get_value()==1,msg="Incorrect output when state = in1 = in2 = 1.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    A1 = AndVariable('A1') 
    model = Model()
    model += A == 1
    model += B == 0
    model += A1 == 1
    model = f(model,A1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in1 = 1, in2 = 0.") 
    ok_(C.get_value()==0,msg="Incorrect output when state = in1 = 1, in2 = 0.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    A1 = AndVariable('A1') 
    model = Model()
    model += A == 0
    model += B == 1
    model += A1 == 1
    model = f(model,A1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in2 = 1, in1 = 0.") 
    ok_(C.get_value()==0,msg="Incorrect output when state = in2 = 1, in1 = 0.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    A1 = AndVariable('A1') 
    model = Model()
    model += A == 0
    model += B == 0
    model += A1 == 1
    model = f(model,A1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = 1, in1 = in2 = 0.") 
    ok_(C.get_value()==0,msg="Incorrect output when state = 1, in1 = in2 = 0.") 
    
    test_ok()
    
    
def test_add_XOrVariable(f):
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    X1 = XOrVariable('A1') 
    model = Model()
    model += A == 1
    model += B == 1
    model += X1 == 1
    model = f(model,X1,A,B,C)
    
    # Tests are only using satisfiability.
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in1 = in2 = 1.") 
    ok_(C.get_value()==0,msg="Incorrect output when state = in1 = in2 = 1.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    X1 = XOrVariable('A1')  
    model = Model()
    model += A == 1
    model += B == 0
    model += X1 == 1
    model = f(model,X1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in1 = 1, in2 = 0.") 
    ok_(C.get_value()==1,msg="Incorrect output when state = in1 = 1, in2 = 0.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    X1 = XOrVariable('A1') 
    model = Model()
    model += A == 0
    model += B == 1
    model += X1 == 1
    model = f(model,X1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = in2 = 1, in1 = 0.") 
    ok_(C.get_value()==1,msg="Incorrect output when state = in2 = 1, in1 = 0.")
    
    A = Variable('A')
    B = Variable('B')
    C = Variable('C')
    X1 = XOrVariable('A1') 
    model = Model()
    model += A == 0
    model += B == 0
    model += X1 == 1
    model = f(model,X1,A,B,C)
    
    solver = model.load('SCIP')
    solver.solve()  
    ok_(solver.is_sat(),msg="No solution found when state = 1, in1 = in2 = 0.") 
    ok_(C.get_value()==0,msg="Incorrect output when state = 1, in1 = in2 = 0.") 
    
    test_ok()
    
def test_update_kernel_diagnoses(f):
    
    # Using the in-class example
    kernel_diagnoses = []
    conflict = set([('A1',1),('A2',1),('X1',1)])
    kernel_diagnoses = f(kernel_diagnoses,conflict)
    
    ok_(len(kernel_diagnoses)==3,msg="Wrong length of kernel_diagnoses.")
    ok_(set([('A1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A2',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('X1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    
    conflict = set([('A1',1),('A3',1),('X1',1),('X2',1)])
    kernel_diagnoses = f(kernel_diagnoses,conflict)
    
    ok_(len(kernel_diagnoses)==4,msg="Wrong length of kernel_diagnoses.")
    ok_(set([('A2',0),('A3',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A2',0),('X2',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('X1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    
    # Make sure we get the same thing the other way around
    kernel_diagnoses = []
    conflict = set([('A1',1),('A3',1),('X1',1),('X2',1)])
    kernel_diagnoses = f(kernel_diagnoses,conflict)
    conflict = set([('A1',1),('A2',1),('X1',1)])
    kernel_diagnoses = f(kernel_diagnoses,conflict)
    
    ok_(len(kernel_diagnoses)==4,msg="Wrong length of kernel_diagnoses.")
    ok_(set([('A2',0),('A3',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A2',0),('X2',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('X1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    
    test_ok()
    
def test_all_kernel_diagnoses(f):
    
    # Using the in-class example
    conflicts = [set([('A1',1),('A2',1),('X1',1)]),set([('A1',1),('A3',1),('X1',1),('X2',1)])]
    kernel_diagnoses = f(conflicts)
    
    ok_(len(kernel_diagnoses)==4,msg="Wrong length of kernel_diagnoses.")
    ok_(set([('A2',0),('A3',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A2',0),('X2',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('X1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")
    ok_(set([('A1',0)]) in kernel_diagnoses,msg="Missing element of kernel_diagnoses.")

    test_ok()