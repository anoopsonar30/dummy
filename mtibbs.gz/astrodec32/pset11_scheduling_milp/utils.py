import IPython
from nose.tools import assert_equal, ok_
import csv
from IPython.display import SVG
from xml.dom import minidom
import networkx as nx

def test_ok():
    try:
        from IPython.display import display_html
        display_html("""<div class="alert alert-success">
        <strong>Test passed!!</strong>
        </div>""", raw=True)
    except:
        print("test ok!!")

def load_adjacent_states():
    adjacent_states = dict()
    with open('adjacent_states.csv', 'rt') as f:
        reader = csv.reader(f)
        #print(reader)
        for state_adj in reader:
            #print(state_adj)
            state = state_adj[0].strip()
            if state[0] == '#':
                continue # this is just a comment
            adjacent_states[state] = state_adj[1:]
    return adjacent_states


def plot_map(state_colors):
    doc = minidom.parse('Blank_US_Map.svg')  # parseString also exists
    path_strings = [path.getAttribute('d') for path
                    in doc.getElementsByTagName('path')]

    for p in doc.getElementsByTagName('path') + doc.getElementsByTagName('circle'):
    #     print p.getAttribute('id')
        st = p.getAttribute('id').upper()
        if st == 'MI-': st = 'MI'
        if st == 'SP-': st = 'MI'
        if st in state_colors:
            p.attributes['style'] = 'fill:' + state_colors[st]
        else:
            pass
            # print "st: %s not in solution" % st

    svg_map =  doc.toxml()
    doc.unlink()

    return SVG(svg_map)

def check_color_assignments(valid_colors, color_assignments, color_counts):
    adjacent_states = load_adjacent_states()
    # Check number of states
    assert_equal(len(adjacent_states), 51, msg="color assignments needs to contain 51 entries, it has %d"%len(color_assignments))
    # Check no duplicate states
    assert_equal(len(set(adjacent_states.keys())), 51, msg="Your color assignments contains duplicate entries for some states.")

    # Check consistent assignments
    computed_counts = [0] * len(valid_colors)
    for st, adjacent_list in adjacent_states.items():
        ok_(st in color_assignments, msg="State %s not found in your color_assignments" % st)
        st_col = color_assignments[st]
        ok_(st_col in valid_colors, msg="State %s is assigned %s, but that color is not in valid_colors" %(st, st_col))
        computed_counts[valid_colors.index(st_col)] += 1
        for adj in adjacent_list:
            ok_(st_col != color_assignments[adj], msg="State %s and %s have both color %s, but they are adjacent!" %(st,adj,st_col))


    # Check color counts
    assert_equal(color_counts, computed_counts, msg="Your color counts are wrong.")

    # test_ok()

def test_combinations(combinations, items):
    repeated_elements = False
    num_elements_ok = True
    no_repeated_combs_ok = True
    all_elements_ok = True
    combs_set = set()
    for c in combinations:
        all_elements_ok = reduce(lambda a,b: a and (b in items),c, True)
        if not all_elements_ok: break
        repeated_elements = len(c) > len(frozenset(c))
        if repeated_elements: break
        num_elements_ok = 1 <= len(c) <= 9
        if not num_elements_ok: break
        if frozenset(c) in combs_set:
            no_repeated_combs_ok = False
            break
        else:
            combs_set.add(frozenset(c))
    assert_equal(all_elements_ok, True, msg="Elements of some combinations are not part of %s"%items)
    assert_equal(repeated_elements, False, msg="Some combinations have repeated elements.")
    assert_equal(num_elements_ok, True, msg="Some combinations have less than 1 or more than 9 elements.")
    assert_equal(no_repeated_combs_ok, True, msg="Some combinations are repeated.")


def test_valid_combinations(combinations, sizes, knapsack_size):
    for c in combinations:
        ok_(sum([sizes[el] for el in c if el in sizes]) <= knapsack_size,
            msg="The cummulative size of the combination %s is greater than the knapsack size %d" %(c, knapsack_size))

"""
Example STNs
"""

def create_example_stn_1():
    """Helper to create and return an example STN."""
    stn = nx.DiGraph()
    stn.add_edge('A', 'B', stc=[0, 10])
    stn.add_edge('B', 'D', stc=[1, 1])
    stn.add_edge('A', 'C', stc=[0, 10])
    stn.add_edge('C', 'D', stc=[2, 2])
    return stn

def create_example_stn_2():
    """Helper to create and return an example STN."""
    stn = nx.DiGraph()
    stn.add_edge('A', 'B', stc=[1.0, 2.0])
    stn.add_edge('C', 'D', stc=[1.0, 2.0])
    stn.add_edge('E', 'F', stc=[1.0, 2.0])
    stn.add_edge('B', 'C', stc=[0, np.inf])
    stn.add_edge('D', 'E', stc=[0, np.inf])
    stn.add_edge('A', 'F', stc=[0, 4.0])
    return stn

"""
Tests for scheduling helper functions
"""

def test_distance_graph(dg, stn):
    if set(dg.nodes()) != set(stn.nodes()):
        raise Exception("Distance graph and STN don't have same events!")
    if len(dg.edges()) != 2*len(stn.edges()):
        raise Exception("Wrong number of edges between distance graph and STN!")
    for (u, v) in stn.edges():
        lb, ub = stn[u][v]['stc']
        if dg[u][v]['weight'] != ub:
            raise Exception("Invalid upper bound edge!")
        elif dg[v][u]['weight'] != -lb:
            raise Exception("Invalid lower bound edge!")

def test_apsp_example_stn_1(g_apsp):
    # Correct events
    assert_equal(set(g_apsp.nodes()), set(['A', 'B', 'C', 'D']))

    # No self-loops
    for u in g_apsp.nodes():
        ok_(not u in g_apsp[u], msg="Has self-loops but shouldn't!")

    # Correct edges
    assert_equal(len(g_apsp.edges()), 12, msg="Incorrect number of edges")

    assert_equal(g_apsp['A']['B']['weight'], 10.0, msg="Invalid edge weight")
    assert_equal(g_apsp['B']['A']['weight'], -1.0, msg="Invalid edge weight")

    assert_equal(g_apsp['A']['C']['weight'], 9.0, msg="Invalid edge weight")
    assert_equal(g_apsp['C']['A']['weight'], 0.0, msg="Invalid edge weight")

    assert_equal(g_apsp['A']['D']['weight'], 11.0, msg="Invalid edge weight")
    assert_equal(g_apsp['D']['A']['weight'], -2.0, msg="Invalid edge weight")

    assert_equal(g_apsp['B']['C']['weight'], -1.0, msg="Invalid edge weight")
    assert_equal(g_apsp['C']['B']['weight'], 1.0, msg="Invalid edge weight")

    assert_equal(g_apsp['B']['D']['weight'], 1.0, msg="Invalid edge weight")
    assert_equal(g_apsp['D']['B']['weight'], -1.0, msg="Invalid edge weight")

    assert_equal(g_apsp['C']['D']['weight'], 2.0, msg="Invalid edge weight")
    assert_equal(g_apsp['D']['C']['weight'], -2.0, msg="Invalid edge weight")

"""
Tests for schedulers
"""

def check_offline_scheduler(fn, N=100, epsilon=1e-10):
    stn = create_example_stn_1()
    # Students may (or may not) use randomization in their scheduler algorithm.
    # In case they do, take a Monte-Carlo approach and try their scheduler function
    # a bunch of times to makes sure it works.
    for i in range(N):
        schedule = fn(stn, 'A')
        satisfied, explanation = check_schedule_against_stn(stn, schedule, epsilon=epsilon)
        if not satisfied:
            raise Exception(explanation)

def check_schedule_against_stn(stn, schedule, epsilon=1e-10):
    """Verifies that the given schedule satisfies all
    of the temporal constraints in the STN.

    Inputs: stn - a networkx.digraph with STCs (simple temporal constraints)
                  representing an STN
            schedule - a dictionary, mapping event names (nodes in stn) to
                       float values (scheduled times)

    Output: A tuple (satisfied, explanation). satisfied is True if all
            temporal constraints are satisifed, else its False. explanation is
            a string describing why it's unsatisfied (if it is), otherwise it's
            a kind message.
    """
    for (u, v) in stn.edges():
        # Retrieve the STC for this edge
        lb, ub = stn[u][v]['stc']
        stc_satisfied = ((schedule[v] - schedule[u] <= ub + epsilon) and
                         (schedule[v] - schedule[u] >= lb - epsilon))
        if not stc_satisfied:
            return (False,
                    ("There's a temporal constraint [{}, {}] from {} to {}, "
                     "but those events were scheduled at {}={:0.4f} and {}={:0.4f} "
                     "for a difference of {:0.4f}, violating the temporal constraint!").format(
                        lb, ub, u, v, u, schedule[u], v, schedule[v], schedule[v] - schedule[u]))
    # All edges satisfied
    return (True, "Great!")
