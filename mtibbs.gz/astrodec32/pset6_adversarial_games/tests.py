from utils import *
from nose.tools import assert_equal, ok_

# Function for tests
def test_ok():
    try:
        from IPython.display import display_html
        display_html("""<div class="alert alert-success">
        <strong>Test passed!!</strong>
        </div>""", raw=True)
    except:
        print("test ok!!")


def test_minimax(fmax,fmin):    
    test_state = game_state(tic_tac_toe_board(['x','o','x','x','x','o','o',' ','o']))
    result = fmax(test_state)
    ok_(isinstance(result,tuple) and len(result) == 3, "Result should be a 3-tuple")
    assert_equal(result[0], 0, "From ['x','o','x','x','x','o','o',' ','o'] max score should be 0.")
    assert_equal(result[1], 2, "From ['x','o','x','x','x','o','o',' ','o'] number of explored states should be 2.")
    assert_equal(len(result[2]), 2, "From ['x','o','x','x','x','o','o',' ','o'] optimal play should have 2 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x','x','o','o',' ','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x','x','o','o','x','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")

    test_state = game_state(tic_tac_toe_board(['x','o','x','x',' ','o','o',' ','o']))
    result = fmax(test_state)
    assert_equal(result[0], 0, "From ['x','o','x','x',' ','o','o',' ','o'] max score should be 0.")
    assert_equal(result[1], 5, "From ['x','o','x','x',' ','o','o',' ','o'] number of explored states should be 5.")
    assert_equal(len(result[2]), 3, "From ['x','o','x','x',' ','o','o',' ','o'] optimal play should have 3 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x',' ','o','o',' ','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x',' ','o','o','x','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['x','o','x','x','o','o','o','x','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    
    test_state = game_state(tic_tac_toe_board(['x','o',' ','x',' ',' ','o',' ',' ']))
    result = fmax(test_state)
    assert_equal(result[0], 1, "From ['x','o',' ','x',' ',' ','o',' ',' '] max score should be 1.")
    assert_equal(result[1], 246, "From ['x','o',' ','x',' ',' ','o',' ',' '] number of explored states should be 246.")
    for i in result[2]:
        print(i)
    assert_equal(len(result[2]), 4, "From ['x','o',' ','x',' ',' ','o',' ',' '] optimal play should have 4 states.")
    assert_equal(result[2][0].board.moves, ['x','o',' ','x',' ',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o',' ','x','x',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['x','o','o','x','x',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][3].board.moves, ['x','o','o','x','x','x','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")

    test_state = game_state(tic_tac_toe_board(['x','o','x','x','x','o','o',' ','o']))
    test_state.player = 2
    result = fmin(test_state)
    ok_(isinstance(result,tuple) and len(result) == 3, "Result should be a 3-tuple")
    assert_equal(result[0], -1, "From ['x','o','x','x','x','o','o',' ','o'] min score should be -1.")
    assert_equal(result[1], 2, "From ['x','o','x','x','x','o','o',' ','o'] number of explored states should be 2.")
    assert_equal(len(result[2]), 2, "From ['x','o','x','x','x','o','o',' ','o'] optimal play should have 2 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x','x','o','o',' ','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x','x','o','o','o','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    
    test_state = game_state(tic_tac_toe_board(['o','x','o','o',' ','x','x',' ','x']))
    test_state.player = 2
    result = fmin(test_state)
    assert_equal(result[0], 0, "From ['o','x','o','o',' ','x','x',' ','x'] min score should be 0.")
    assert_equal(result[1], 5, "From ['o','x','o','o',' ','x','x',' ','x'] number of explored states should be 5.")
    assert_equal(len(result[2]), 3, "From ['o','x','o','o',' ','x','x',' ','x'] optimal play should have 3 states.")
    assert_equal(result[2][0].board.moves, ['o','x','o','o',' ','x','x',' ','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['o','x','o','o',' ','x','x','o','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['o','x','o','o','x','x','x','o','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")

    test_ok()
    
 
def test_alpha_beta(fmax,fmin):    
    test_state = game_state(tic_tac_toe_board(['x','o','x','x','x','o','o',' ','o']))
    result = fmax(test_state,-2,2)
    ok_(isinstance(result,tuple) and len(result) == 3, "Result should be a 3-tuple")
    assert_equal(result[0], 0, "From ['x','o','x','x','x','o','o',' ','o'] max score should be 0.")
    assert_equal(result[1], 2, "From ['x','o','x','x','x','o','o',' ','o'] number of explored states should be 2.")
    assert_equal(len(result[2]), 2, "From ['x','o','x','x','x','o','o',' ','o'] optimal play should have 2 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x','x','o','o',' ','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x','x','o','o','x','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")

    test_state = game_state(tic_tac_toe_board(['x','o','x','x',' ','o','o',' ','o']))
    result = fmax(test_state,-2,2)
    assert_equal(result[0], 0, "From ['x','o','x','x',' ','o','o',' ','o'] max score should be 0.")
    assert_equal(result[1], 5, "From ['x','o','x','x',' ','o','o',' ','o'] number of explored states should be 5.")
    assert_equal(len(result[2]), 3, "From ['x','o','x','x',' ','o','o',' ','o'] optimal play should have 3 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x',' ','o','o',' ','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x',' ','o','o','x','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['x','o','x','x','o','o','o','x','o'], "From ['x','o','x','x',' ','o','o',' ','o'] incorrect optimal play.")
    
    test_state = game_state(tic_tac_toe_board(['x','o',' ','x',' ',' ','o',' ',' ']))
    result = fmax(test_state,-2,2)
    assert_equal(result[0], 1, "From ['x','o',' ','x',' ',' ','o',' ',' '] max score should be 1.")
    assert_equal(result[1], 89, "From ['x','o',' ','x',' ',' ','o',' ',' '] number of explored states should be 89.")
    assert_equal(len(result[2]), 4, "From ['x','o',' ','x',' ',' ','o',' ',' '] optimal play should have 4 states.")
    assert_equal(result[2][0].board.moves, ['x','o',' ','x',' ',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o',' ','x','x',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['x','o','o','x','x',' ','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")
    assert_equal(result[2][3].board.moves, ['x','o','o','x','x','x','o',' ',' '], "From ['x','o',' ','x',' ',' ','o',' ',' '] incorrect optimal play.")

    test_state = game_state(tic_tac_toe_board(['x','o','x','x','x','o','o',' ','o']))
    test_state.player = 2
    result = fmin(test_state,-2,2)
    ok_(isinstance(result,tuple) and len(result) == 3, "Result should be a 3-tuple")
    assert_equal(result[0], -1, "From ['x','o','x','x','x','o','o',' ','o'] min score should be -1.")
    assert_equal(result[1], 2, "From ['x','o','x','x','x','o','o',' ','o'] number of explored states should be 2.")
    assert_equal(len(result[2]), 2, "From ['x','o','x','x','x','o','o',' ','o'] optimal play should have 2 states.")
    assert_equal(result[2][0].board.moves, ['x','o','x','x','x','o','o',' ','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['x','o','x','x','x','o','o','o','o'], "From ['x','o','x','x','x','o','o',' ','o'] incorrect optimal play.")
    
    test_state = game_state(tic_tac_toe_board(['o','x','o','o',' ','x','x',' ','x']))
    test_state.player = 2
    result = fmin(test_state,-2,2)
    assert_equal(result[0], 0, "From ['o','x','o','o',' ','x','x',' ','x'] min score should be 0.")
    assert_equal(result[1], 5, "From ['o','x','o','o',' ','x','x',' ','x'] number of explored states should be 5.")
    assert_equal(len(result[2]), 3, "From ['o','x','o','o',' ','x','x',' ','x'] optimal play should have 3 states.")
    assert_equal(result[2][0].board.moves, ['o','x','o','o',' ','x','x',' ','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")
    assert_equal(result[2][1].board.moves, ['o','x','o','o',' ','x','x','o','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")
    assert_equal(result[2][2].board.moves, ['o','x','o','o','x','x','x','o','x'], "From ['o','x','o','o',' ','x','x',' ','x'] incorrect optimal play.")

    test_ok()